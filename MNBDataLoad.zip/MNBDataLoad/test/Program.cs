﻿using mnbDataLoad;
using System;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using currencies.Models;

namespace currencies
{
    class Program
    {
        static void Main(string[] args)
        {
            Task.Run(async () => await MainAsync(args)).Wait();
        }

        static async Task MainAsync(string[] args)
        {
            var client = new MNBArfolyamServiceSoapClient();

            var currencies = await client.GetCurrenciesAsync(new GetCurrenciesRequestBody());

            var bytes = Encoding.UTF8.GetBytes(currencies.GetCurrenciesResponse1.GetCurrenciesResult);
            var stream = new MemoryStream(bytes);

            var serializer = new XmlSerializer(typeof(MNBCurrencies));
            var deserialized = (MNBCurrencies)serializer.Deserialize(stream);

             var getExchangeRates = await client.GetExchangeRatesAsync(new GetExchangeRatesRequestBody() 
            { 
                currencyNames = string.Join(",",deserialized.Currencies.Curr),
                startDate = "2020-04-01",
                endDate = "2020-04-01"
            });

            var bytes2 = Encoding.UTF8.GetBytes(getExchangeRates.GetExchangeRatesResponse1.GetExchangeRatesResult);
            var stream2 = new MemoryStream(bytes2);

            var serializer2 = new XmlSerializer(typeof(MNBExchangeRates));
            var deserialized2 = (MNBExchangeRates)serializer.Deserialize(stream2);

            var csvFile = string.Join(";", deserialized2);

            await client.CloseAsync();
        }
    }
}
